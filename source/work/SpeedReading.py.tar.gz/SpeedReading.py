#!/usr/bin/env python3
# -*- coding:utf-8 -*-
'''SpeedReading.py
Speed up your reading!
Author: Tianhu Zhang <zszth@126.com>
Run with option -h or --help to show help.
'''
__author__ = 'Tianhu Zhang'

import tkinter as tk
from tkinter import font
import chardet
import sys
import getopt
import os
# Settings.
hanzi_per_min = 750
hanzi_at_a_time = 3
hanzi_size = 72

# Constants.
pos = 0
txt = '废话还是不要多说的好，除非你是在凑字数。'
reading = False

# Getting variants.
def help():
    print('''SpeedReading.py
Usage: python3 SpeadReading.py [options] FILENAME
Press any key to resume or pause.
Option list:
    -p NUM, --pos=NUM   Specify beginning position. 0 by default. (Useful as a bookmark)
    -s NUM, --speed=NUM Specify the number of hanzi per minute. 750 by default
    -w NUM, --width=NUM Specify the width of display. 3 by default
    -z NUM, --size=NUM  Specify the font size. 72 by default
    -h,     --help      Show this help
Position number will be given every time when exit.''')
if len(sys.argv) < 2:
    file_path = input('Input file name (or path): >')
    pos = int(input('Input position: >'))
else:
    try:
        options,args = getopt.getopt(sys.argv[1:], 'hp:s:w:z:', ['help', 'pos=', 'speed=', 'width=', 'size='])
        if args:
            file_path = args[0]
            if not os.path.isfile(file_path):
                print('File not found.')
                exit()
            for opt, value in options:
                if opt in ['-p', '--pos']:
                    pos = int(value)
                if opt in ['-s', '--speed']:
                    hanzi_per_min = int(value)
                if opt in ['-w', '--width']:
                    hanzi_at_a_time = int(value)
                if opt in ['-z', '--size']:
                    hanzi_size = int(value)
        else:
            help()
            exit()
    except getopt.GetoptError:
        help()
        exit()


# Loading file.
with open(file_path, mode = 'rb') as f:
    # print(chardet.detect(f.read())['encoding'])
    data = f.read()
    code = chardet.detect(data)['encoding']
    txt = data.decode(code)
txt = '文始>' + txt.replace('\n', '  ') + '<文末'

# Preparing window.
root = tk.Tk()
root.title("速读 " + file_path)
show_font = font.Font(family = 'serif', size = hanzi_size, weight = 'normal')
show = tk.Label(root, text = '预备！', font = show_font)
def toogle(event):
    global reading
    reading = not reading
root.bind('<KeyPress>', toogle)
show.pack()
def timer():
    global pos
    if reading and pos < len(txt) - (hanzi_at_a_time - 1):
        show.config(text = txt[pos: pos + hanzi_at_a_time])
        pos = pos + 1
    root.after(int(1000 * 60 / hanzi_per_min), timer)

# Start.
timer()
print('Press any key to resume or pause...')
show.config(text = txt[pos: pos + hanzi_at_a_time])
root.mainloop()
print('Stop at position {0}.'.format(pos))
if pos == len(txt) - (hanzi_at_a_time - 1):
    print('Reading finished.')
