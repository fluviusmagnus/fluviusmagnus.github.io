#!/usr/bin/env python3
# -*- coding:utf-8 -*-
'''youkudownloader.py

Author: Tianhu Zhang <zszth@126.com>
License: GPLv3
Version: 20150217

A python3 script for downloading videos from youku.com.
Using flvcd.com to get source urls.
Using mencoder to merge files.

IMPORTANT!!
1. This script works ONLY under LINUX (or other unix-like systems).
2. Please make sure that you have mencoder installed.
In Ubuntu (or other similar linux distributions), enter this in your
shell to install mencoder:
    sudo apt-get install mencoder
Installations on other systems may vary.

Usage:
    In shell enter:
        chmod +x youkudownloader.py #Do this for the first time.
        python3 youkudownloader.py video_url
    And video_url should be replaced by the url of Youku video id page,
    such as http://v.youku.com/v_show/id_XMzA2NTM4NDQ0.html
    Or you can leave it empty and type the url in when asked.
'''
__author__ = 'Tianhu Zhang'
import urllib.request
import re
import os
FLVCD_URL = 'http://www.flvcd.com/parse.php?kw='
# video_id_page = 'http://v.youku.com/v_show/id_XMzA2NTM4NDQ0.html'

def get_info(video_id_page):
    parse_page = urllib.request.urlopen(FLVCD_URL+video_id_page).read().decode('gb2312')
    # print(parse_page)
    urls_unparsed = re.findall(r'<a href=".*?" target="_blank" onclick=\'_alert\(\);return false;\'>', parse_page)
    urls = []
    for url in urls_unparsed:
        urls.append(url[9:-51])
    # print(urls)
    # print(len(urls))
    title = re.findall(r'<strong>当前解析视频：</strong>.*?<strong>', parse_page)[0][24:-8].strip(' ')
    title = re.sub(r'[ /#$&()-\\\t*?+.,\'"_`~|<>{}^]', "", title)
    # print(title)
    return [urls, title]

def download(info):
    para = ''
    for i in range(len(info[0])):
        with open(info[1]+'_{0}.flv'.format(i), mode='wb') as f:
            print('Downloading part {0} of {1}...'.format(i+1, len(info[0])))
            data = urllib.request.urlopen(info[0][i]+'&referer=www.youku.com').read()
            f.write(data)
        para = para + ' ' + info[1]+'_{0}.flv'.format(i)
    cmd = 'mencoder -ovc copy -oac mp3lame' + para + ' -o ' +info[1] +'.flv'
    print('Merging...')
    if os.system(cmd) == 0:
        print('Done. File saved to ' + info[1] +'.flv successfully.')
        os.system('rm ' + info[1] + '_*.flv')

if __name__ == '__main__':
    if len(os.sys.argv)<2:
        video_id_page = input('Input video id page full url: >')
    else:
        video_id_page = os.sys.argv[1]
    video = get_info(video_id_page)
    download(video)
