#!/usr/bin/env python3
# -*- coding:utf-8 -*-
'''renrenobj.py

Renren defines a lot of special types.
This is a library of types returned in JSON.
'''
import json
import urllib.request
import urllib.parse
import easygui as g


A_T = ''
USER_ID = 0


def get_json_get(url_in):
    '''Function get_json_get
    GET mode.
    This returns an object loaded from json.
    When error return None.
    Make sure the end of url_in and the beginning of a_t are correct.
    If url_in is with a parameter, add a '&' after it.
    '''
    data = urllib.request.urlopen(url_in + 'access_token=' + A_T).read()
    json_data = data.decode('UTF-8')
    obj = json.loads(json_data, encoding='UTF-8')
    if 'error' in obj:
        g.msgbox(str(obj), 'Error')
        return None
    else:
        return obj['response']


def get_json_post(url_in, para):
    '''Function get_json_post
    POST mode.
    para should be a dict.
    This returns an object loaded from json.
    When error return None.
    Make sure the end of url_no_a_t and the beginning of a_t are correct.
    '''
    postdata = urllib.parse.urlencode(para).encode(encoding='UTF-8')
    json_data = urllib.request.urlopen(url_in + 'access_token=' + A_T, postdata).read().decode('UTF-8')
    obj = json.loads(json_data, encoding='UTF-8')
    if 'error' in obj:
        g.msgbox(str(obj), 'Error')
        return None
    else:
        return obj['response']


class Feed:
    '''Class Feed

    This deals with the feed list.
    a_t should be passed in when init.
    '''
    URL_GET_FEED_LIST = 'https://api.renren.com/v2/feed/list?'

    def __init__(self):
        self.feed_list = get_json_get(self.URL_GET_FEED_LIST)
        if self.feed_list:
            self.feed_list = list(self.feed_list)
            # If the list is None then do nothing.
            # Abandoned.
            # if self.feed_list:
            # for feed in self.feed_list['response']:
            # self.simplist.append(
            #             {'id': feed['id'], 'time': feed['time'], 'resource_content': feed['resource']['content'],
            #              'user': feed['sourceUser']['name'], 'message': feed['message'],
            #              'resource_title': feed['resource']['title'], 'resource_id': feed['resource']['id'], 'type': feed['type'], 'user_id': feed['sourceUser']['id'],})

    def show_feed_list(self):
        for i in range(len(self.feed_list)):
            print('{0} {1} {2}\n    {3}\n    source: {4}\n            {5}'.format(i, self.feed_list[i]['time'],
                                                                                  self.feed_list[i]['sourceUser'][
                                                                                      'name'],
                                                                                  self.feed_list[i]['message'],
                                                                                  self.feed_list[i]['resource'][
                                                                                      'title'],
                                                                                  self.feed_list[i]['resource'][
                                                                                      'content']),
                  end='\n\n\n')

    def show_comment(self):
        i = int(input('Input id to enter: >'))
        c = Comment(self.feed_list[i]['type'],
                    self.feed_list[i]['sourceUser']['id'],
                    self.feed_list[i]['resource']['id'])
        cl = c.comment_list
        print('|{0} {1} {2}\n|    {3}\n|    source: {4}\n|            {5}'.format(i, self.feed_list[i]['time'],
                                                                                  self.feed_list[i]['sourceUser'][
                                                                                      'name'],
                                                                                  self.feed_list[i]['message'],
                                                                                  self.feed_list[i]['resource'][
                                                                                      'title'],
                                                                                  self.feed_list[i]['resource'][
                                                                                      'content']),
              end='\n\n\n')
        for j in range(len(cl)):
            print('{0} {1} {2}\n    {3}'.format(j, cl[j]['time'], User.get_user_name(User, cl[j]['authorId']),
                                                cl[j]['content']), end='\n\n')
            # ctrl = int(input('Input a positive number to comment: >'))
            # if ctrl > 0:
            # c.make_comment()


class Comment:
    URL_GET_COMMENT_LIST = 'https://api.renren.com/v2/comment/list?'

    def __init__(self, commentType, entryOwnerId, entryId):
        '''Function __init__

        entryId should be resource id.
        '''
        self.entryOwnerId = entryOwnerId
        self.entryId = entryId
        if 'SHARE' in commentType:
            self.commentType = 'SHARE'
        if 'UPDATE' in commentType:
            self.commentType = commentType[7:]
        para = 'commentType={0}&entryOwnerId={1}&entryId={2}&'.format(self.commentType, self.entryOwnerId, self.entryId)
        self.comment_list = get_json_get(self.URL_GET_COMMENT_LIST + para)
        if self.comment_list:
            self.comment_list = list(self.comment_list)

    def make_comment(self, i):
        URL_MAKE_COMMENT = 'https://api.renren.com/v2/comment/put?'
        # i = int(input('Input id to send to,\nNegative number not to specify: >'))
        if i >= 0 and self.comment_list[i]['authorId'] == USER_ID:
            g.msgbox('Cannot reply to yourself!', 'Error')
            return
        text = g.enterbox('Input the content:', 'Comment')
        if text:
            if i < 0:
                para = {'content': text,
                        'commentType': self.commentType,
                        'entryOwnerId': self.entryOwnerId,
                        'entryId': self.entryId}
                obj = get_json_post(URL_MAKE_COMMENT, para)
                if obj:
                    g.msgbox('Done.', 'Comment')
            else:
                para = {'content': text,
                        'commentType': self.commentType,
                        'entryOwnerId': self.entryOwnerId,
                        'entryId': self.entryId,
                        'targetUserId': self.comment_list[i]['authorId']}
                obj = get_json_post(URL_MAKE_COMMENT, para)
                if obj:
                    g.msgbox('Done.', 'Comment')


def status_pub():
    text = g.enterbox('Input status:', 'Update Status')
    if text:
        URL_STATUS_PUB = 'https://api.renren.com/v2/status/put?'
        obj = get_json_post(URL_STATUS_PUB, {'content': text})
        if obj:
            g.msgbox('Done.', 'Update Status')


class User:
    '''Class User

    This deals with user info.
    '''
    user_id = 0
    user_name = ''

    def __init__(self, user_id):
        self.user_id = user_id

    def get_user_name(self, user_id):
        URL_GET_USER_NAME = 'https://api.renren.com/v2/user/get?'
        obj = get_json_get(URL_GET_USER_NAME + 'userId={0}'.format(user_id) + '&')
        if obj:
            self.user_name = obj['name']
            return self.user_name
