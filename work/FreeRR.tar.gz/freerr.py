#!/usr/bin/env python3
# -*- coding:utf-8 -*-
'''freerr.py

This is an attempt to make a client for Renren on Linux using Python3.
Author: Tianhu Zhang <zszth@126.com> (A beginner to Python3)
renren.py is the main file which includes the very basic auth work.
And all the editable constants are listed in this file for convenience.
More useful classes are in renrenobj.py and should be imported before use.
'''
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import urllib.request
import json
import renrenobj
import os
# import getpass
import easygui as g
# import glob
import webbrowser

REFRESH_TOKEN = ''
ACCESS_TOKEN = ''
USER_ID = 0

if os.path.isfile(os.path.join(os.path.expanduser('~/.freerr'), '.freerr')):
    with open(os.path.join(os.path.expanduser('~/.freerr'), '.freerr'), mode='r', encoding='UTF-8') as conf_file:
        ACCESS_TOKEN = conf_file.readline()
        USER_ID = int(conf_file.readline())
else:
    # user_email = input('Input Email to login: >')
    # user_password = getpass.unix_getpass('Input password: >')
    user_email = g.enterbox('Input Email to login:', 'Login')
    user_password = g.passwordbox('Input password:', 'Login')
    browser = webdriver.Firefox()
    browser.get(
        'https://graph.renren.com/oauth/authorize?client_id=db5c847cd976402da999ce84f540872f&redirect_uri=http://e.koccn.net/freerr.php&response_type=code')
    username = browser.find_element_by_name('username')
    username.send_keys(user_email)
    password = browser.find_element_by_name('password')
    password.send_keys(user_password)
    password.send_keys(Keys.ENTER)
    json_inputbox = browser.find_element_by_tag_name('textarea')
    a_t_data = json.loads(json_inputbox.text, encoding='UTF-8')
    browser.close()
    # REFRESH_TOKEN = a_t_data['refresh_token']
    ACCESS_TOKEN = a_t_data['access_token']
    USER_ID = a_t_data['user']['id']
    os.mkdir(os.path.expanduser('~/.freerr'))
    with open(os.path.join(os.path.expanduser('~/.freerr'), '.freerr'), mode='w', encoding='utf-8') as conf_file:
        conf_file.writelines(ACCESS_TOKEN + '\n')
        conf_file.writelines(str(USER_ID))
renrenobj.A_T = ACCESS_TOKEN
renrenobj.USER_ID = USER_ID

f = renrenobj.Feed()

flag_exit = False
i = 0
while not flag_exit:
    if f.feed_list[i]['attachment'] and f.feed_list[i]['attachment'][0]['orginalUrl']:
        if not os.path.isfile(
                os.path.join(os.path.expanduser('~/.freerr'), '.freerr_' + str(f.feed_list[i]['resource']['id']))):
            img_data = urllib.request.urlopen(f.feed_list[i]['attachment'][0]['orginalUrl']).read()
            with open(os.path.join(os.path.expanduser('~/.freerr'), '.freerr_' + str(f.feed_list[i]['resource']['id'])),
                      mode='wb') as img_file:
                img_file.write(img_data)
        choice = g.buttonbox('{0} {1} {2}\n    {3}\n    source: {4}\n            {5}'.format(i, f.feed_list[i]['time'],
                                                                                             f.feed_list[i][
                                                                                                 'sourceUser'][
                                                                                                 'name'],
                                                                                             f.feed_list[i]['message'],
                                                                                             f.feed_list[i]['resource'][
                                                                                                 'title'],
                                                                                             f.feed_list[i]['resource'][
                                                                                                 'content']),
                             'Feed List ' + str(i),
                             ['Next', 'Comment', 'Open Browser', 'Update Status', 'Refresh', 'Exit', 'Prev'],
                             image=os.path.join(os.path.expanduser('~/.freerr'),
                                                '.freerr_' + str(f.feed_list[i]['resource']['id'])))
    else:
        choice = g.buttonbox('{0} {1} {2}\n    {3}\n    source: {4}\n            {5}'.format(i, f.feed_list[i]['time'],
                                                                                             f.feed_list[i][
                                                                                                 'sourceUser'][
                                                                                                 'name'],
                                                                                             f.feed_list[i]['message'],
                                                                                             f.feed_list[i]['resource'][
                                                                                                 'title'],
                                                                                             f.feed_list[i]['resource'][
                                                                                                 'content']),
                             'Feed List ' + str(i),
                             ['Next', 'Comment', 'Update Status', 'Refresh', 'Exit', 'Prev'])
    if choice == 'Prev':
        if i == 0:
            g.msgbox('No Prev!', 'Error')
        else:
            i = i - 1
    elif choice == 'Exit':
        flag_exit = True
    elif choice == 'Next':
        if i == len(f.feed_list) - 1:
            g.msgbox('No Next!', 'Error')
        else:
            i = i + 1
    elif choice == 'Comment':
        c = renrenobj.Comment(f.feed_list[i]['type'], f.feed_list[i]['sourceUser']['id'],
                              f.feed_list[i]['resource']['id'])
        cl = []
        for j in range(len(c.comment_list)):
            cl.append('{0} {1} {2}\n    {3}'.format(j, c.comment_list[j]['time'],
                                                    renrenobj.User.get_user_name(renrenobj.User,
                                                                                 c.comment_list[j]['authorId']),
                                                    c.comment_list[j]['content']))
        cl.append('-1 Make a comment without replying to anyone')
        reply_choice = g.choicebox('Choose a person to reply:', 'Comments List', cl)
        if reply_choice:
            c.make_comment(int(reply_choice.split(' ')[0]))
    elif choice == 'Update Status':
        renrenobj.status_pub()
    elif choice == 'Refresh':
        del f
        f = renrenobj.Feed()
        i = 0
    elif choice == 'Open Browser':
        webbrowser.open(f.feed_list[i]['attachment'][0]['url'])
